# Asana Connector

[Asana](https://asana.com/) is a web and mobile application designed for team collaboration and project management.
It helps teams organize tasks, track progress, assign work, set deadlines, and communicate efficiently.  

The Axon Ivy Asana connector provides the following capabilities:
- Create a task
- Retrieve task details
- Update task details
- Delete a task

## Demo

Check out the demo implementations we have prepared for the Asana connector:

![demo-process](img/demo-process.png).

This demo provides the following features:

1. Create Task
- Creates a new task with sample data (e.g., task name, workspace, project, assignee, start date and due date).
- `Project` and `Assignee` will be fetched base on the selected `Workspace`.
- If the provided `Personal Access Token (PAT)` is invalid, the `Workspace` data will be empty. 
![task-creation](img/task-creation.png).
2. Task List
- Shows a table of tasks base on selected `Workspace` and `Project`
- Two actions can be performed in the `Actions` column: `Delete` and `Update`.
- Clicking `Update` will navigate user to the `Update` page.
![task-table](img/task-table.png).
3. Update Task
- Allows editing task details such as the task name, assignee, start date, and due date.
![task-update](img/task-update.png).

## Setup

In order to use this product you must configure the variables.

Add the following code block to your `config/variables.yaml` file of your main Business Project that will utilize this product:

```
# yaml-language-server: $schema=https://json-schema.axonivy.com/app/12.0.0/variables.json
# == Variables ==
#
# You can define here your project Variables.
# If you want to define/override a Variable for a specific Environment, 
# add an additional ‘variables.yaml’ file in a subdirectory in the ‘Config’ folder: 
# '<project>/Config/_<environment>/variables.yaml
#

# Example Variables:
#  asanaConnector:
#    accessToken: 'AIzaSyDax'
Variables:
  asanaConnector:
    # The PAT key that can be created in https://app.asana.com/0/my-apps.
    accessToken: ''
```

### Asana Registration

1. Register for an Asana account on the [Asana Dashboard](https://asana.com/)
1. Once logged in, [Create a PAT](https://app.asana.com/0/my-apps)
(Personal access token), which you will later add to the `variables.yaml`.
![create-pat](img/create-pat.png)
1. Refer to the [Quick start guide](https://developers.asana.com/docs/quick-start) to learn how to access your Workspace GID.
